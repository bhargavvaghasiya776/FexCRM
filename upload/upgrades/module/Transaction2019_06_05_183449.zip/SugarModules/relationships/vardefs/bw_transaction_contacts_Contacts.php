<?php
// created: 2019-06-05 18:34:49
$dictionary["Contact"]["fields"]["bw_transaction_contacts"] = array (
  'name' => 'bw_transaction_contacts',
  'type' => 'link',
  'relationship' => 'bw_transaction_contacts',
  'source' => 'non-db',
  'module' => 'BW_Transaction',
  'bean_name' => 'BW_Transaction',
  'side' => 'right',
  'vname' => 'LBL_BW_TRANSACTION_CONTACTS_FROM_BW_TRANSACTION_TITLE',
);
