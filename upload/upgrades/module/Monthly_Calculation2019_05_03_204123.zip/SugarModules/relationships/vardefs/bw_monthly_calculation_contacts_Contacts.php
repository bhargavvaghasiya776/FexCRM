<?php
// created: 2019-05-03 20:41:23
$dictionary["Contact"]["fields"]["bw_monthly_calculation_contacts"] = array (
  'name' => 'bw_monthly_calculation_contacts',
  'type' => 'link',
  'relationship' => 'bw_monthly_calculation_contacts',
  'source' => 'non-db',
  'module' => 'BW_Monthly_Calculation',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BW_MONTHLY_CALCULATION_CONTACTS_FROM_BW_MONTHLY_CALCULATION_TITLE',
);
